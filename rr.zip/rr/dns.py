import socket

def dns_lookup(hostname):
    try:
        ip_address = socket.gethostbyname(hostname)
        print(f"The IP address of {hostname} is {ip_address}")
    except socket.error as e:
        print(f"DNS lookup failed: {e}")

if __name__ == "__main__":
    # Input the hostname for DNS lookup
    target_hostname = input("Enter the hostname for DNS lookup: ")

    # Perform DNS lookup
    dns_lookup(target_hostname)
